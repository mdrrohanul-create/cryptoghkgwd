import { pgTable, text, doublePrecision, jsonb, timestamp } from "drizzle-orm/pg-core";

export const portfolioState = pgTable("portfolio_state", {
  id: text().primaryKey(),
  balance: doublePrecision("balance").notNull().default(12847.32),
  assets: jsonb("assets").notNull(),
  txHistory: jsonb("tx_history").notNull(),
  updatedAt: timestamp("updated_at").defaultNow(),
});
