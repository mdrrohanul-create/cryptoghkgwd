# Architecture Notes for AI Agents

## Project Type
Single-file static web app (`index.html`). No build pipeline, no npm, no framework dependencies. Everything lives in one file: HTML structure, `<style>` block with CSS variables, and a `<script>` block with all JS logic.

## Key Architecture Decisions

### Single-file approach
Chosen for zero-dependency deployment on Netlify static hosting. CDN links for Font Awesome icons are the only external dependency.

### CSS Variables
All design tokens defined in `:root` — colors, fonts. Never use hardcoded hex values outside the `:root` block.

### Data model
- `coins[]` — market coin list with price/change/meta
- `trendingCoins[]` — discover/trending section
- `userAssets[]` — portfolio holdings
- `txHistory[]` — transaction log (prepend with `unshift()` on new actions)
- `balance` — single float representing USDT balance

### Live simulation
`startTickers()` runs a 1600ms interval mutating `coins[].price` and `coins[].change` in place, then patching DOM elements by ID (`price-{id}`, `change-{id}`). Futures PnL recalculates off live BTC price.

### Tab system
`switchTab(name)` adds/removes `.active` on both `#tab-{name}` sections and `#nav-{name}` items. Portfolio and Trade tabs re-render their dynamic content on each switch.

### Modals
All modals are `position:fixed` overlays with class `.modal-overlay`. Toggle `.open` class to show/hide. Outer-click dismissal via `closeModalOuter()` checks `e.target === overlay`.

### Toast system
Single `#toast` element, class-toggled with `show` and type (`success`/`error`). Auto-dismissed after 2800ms via `clearTimeout` guard.

## Coding Conventions
- All DOM manipulation via `getElementById` / `querySelector` — no virtual DOM
- Template strings for HTML rendering
- `formatPrice()` handles price display across 8 orders of magnitude
- All monetary formatting uses `toLocaleString('en-US', ...)`
