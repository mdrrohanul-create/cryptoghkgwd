# Binance Pro — Mobile Trading App Clone

A production-grade, pixel-faithful Binance mobile app clone built as a single static HTML file. No frameworks, no build step — just deploy and go.

## Key Technologies

- Vanilla HTML/CSS/JavaScript
- Tailwind-free custom CSS with CSS variables
- Font Awesome 6 icons
- Live price simulation with `setInterval`
- Mobile-first responsive design (max-width 430px)

## Features

- **5-tab navigation**: Markets, Trade, Futures, Earn, Portfolio
- **Live market tickers** — BTC, ETH, BNB, SOL, XRP, DOGE, ADA, AVAX, LINK, PEPE, SHIB, DOT
- **SVG sparkline charts** per coin row
- **Order book** with real-time bid/ask simulation
- **Recent trades feed**
- **Spot trade form** — Limit/Market/Stop, Buy/Sell, 25/50/75/100% fill
- **Futures positions** with ROI, PnL, leverage selector (5x–125x)
- **Earn tab** — Flexible savings with APY cards
- **Portfolio** — asset balances, transaction history, deposit/withdraw/transfer modals
- **Transaction detail slips** with TxID, network, timestamp
- **Search overlay** with live coin filtering
- **Pull-to-refresh** touch gesture
- **Balance hide/show toggle**
- **Banner carousel** with auto-rotation
- **Toast notifications** for all actions

## Running Locally

Open `index.html` directly in any browser — no server required. Or deploy via Netlify for the full CDN experience.
