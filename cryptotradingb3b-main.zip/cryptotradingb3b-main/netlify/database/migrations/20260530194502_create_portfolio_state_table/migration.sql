CREATE TABLE "portfolio_state" (
	"id" text PRIMARY KEY,
	"balance" double precision DEFAULT 12847.32 NOT NULL,
	"assets" jsonb NOT NULL,
	"tx_history" jsonb NOT NULL,
	"updated_at" timestamp DEFAULT now()
);
