import type { Config } from "@netlify/functions";
import { db } from "../../db/index.js";
import { portfolioState } from "../../db/schema.js";
import { eq } from "drizzle-orm";

const DEFAULT_ASSETS = [
  { id: "usdt", name: "Tether", ticker: "USDT", amount: 3847.32, value: 3847.32, change: 0.01, color: "#26A17B", icon: "₮" },
  { id: "btc", name: "Bitcoin", ticker: "BTC", amount: 0.04182, value: 4509.87, change: 2.14, color: "#F7931A", icon: "₿" },
  { id: "eth", name: "Ethereum", ticker: "ETH", amount: 0.9841, value: 3915.73, change: 1.83, color: "#627EEA", icon: "Ξ" },
  { id: "bnb", name: "BNB", ticker: "BNB", amount: 12.4, value: 888.36, change: 3.24, color: "#FCD535", icon: "◆" },
  { id: "sol", name: "Solana", ticker: "SOL", amount: 3.12, value: 639.20, change: 4.73, color: "#9945FF", icon: "◎" },
];

const DEFAULT_TX = [
  { type: "Received", asset: "USDT", amount: 5000, sign: "+", time: "2026-05-30 14:22:05", network: "TRX (TRC20)", txid: "t8ac872e89d120464bb37da091c3efea829d104", uid: "", addr: "", cls: "in" },
  { type: "Withdrawal", asset: "USDT", amount: 350, sign: "-", time: "2026-05-30 09:11:42", network: "BSC (BEP20)", txid: "b0x91da71cc39ea09fbc771ef82a731ea67d10c28", uid: "92485011", addr: "", cls: "out" },
  { type: "Transfer", asset: "BTC", amount: 0.0082, sign: "-", time: "2026-05-29 21:04:17", network: "Bitcoin", txid: "1A1zP1eP5QGefi2DMPTfTL5SLmv7Divf", uid: "", addr: "1A1zP1...Divf", cls: "swap" },
  { type: "Received", asset: "ETH", amount: 0.5, sign: "+", time: "2026-05-28 11:33:51", network: "ETH (ERC20)", txid: "0x7c4da71cc39ea09fbc771ef82a731ea67d10c28", uid: "", addr: "", cls: "in" },
];

export default async (req: Request) => {
  const corsHeaders = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
  };

  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders });
  }

  if (req.method === "GET") {
    const rows = await db.select().from(portfolioState).where(eq(portfolioState.id, "default"));
    if (rows.length === 0) {
      return Response.json(
        { balance: 12847.32, assets: DEFAULT_ASSETS, txHistory: DEFAULT_TX },
        { headers: corsHeaders }
      );
    }
    const row = rows[0];
    return Response.json(
      { balance: row.balance, assets: row.assets, txHistory: row.txHistory },
      { headers: corsHeaders }
    );
  }

  if (req.method === "POST") {
    const { balance, assets, txHistory } = await req.json();
    await db
      .insert(portfolioState)
      .values({ id: "default", balance, assets, txHistory })
      .onConflictDoUpdate({
        target: portfolioState.id,
        set: { balance, assets, txHistory, updatedAt: new Date() },
      });
    return Response.json({ ok: true }, { headers: corsHeaders });
  }

  return new Response("Method not allowed", { status: 405, headers: corsHeaders });
};

export const config: Config = {
  path: "/api/state",
};
